<?php
/**
 * @author
 * @copyright
 * @license
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Object types list view class.
 *
 * @package     Bookstore
 * @subpackage  Views
 */
class BookstoreViewObject_types extends StoreViewLegacyPlular
{
}
?>