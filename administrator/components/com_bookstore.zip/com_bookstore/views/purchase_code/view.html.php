<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Purchase code item view class.
 *
 * @package     Bookstore
 * @subpackage  Views
 */
class BookstoreViewPurchase_code extends StoreViewLegacySingular
{
}
?>