<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Translator item view class.
 *
 * @package     Bookstore
 * @subpackage  Views
 */
class BookstoreViewTranslator extends StoreViewLegacySingular
{
}
?>