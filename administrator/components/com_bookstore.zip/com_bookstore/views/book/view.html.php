<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Book item view class.
 *
 * @package     Bookstore
 * @subpackage  Views
 */
class BookstoreViewBook extends StoreViewLegacySingular
{
}
?>