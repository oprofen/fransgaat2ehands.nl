<?php
/**
 * @author
 * @copyright
 * @license
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Subcategories list view class.
 *
 * @package     Bookstore
 * @subpackage  Views
 */
class BookstoreViewSubcategories extends StoreViewLegacyPlular
{
}
?>