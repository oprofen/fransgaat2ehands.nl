<?php
/**
 * @author
 * @copyright
 * @license
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Countries list view class.
 *
 * @package     Bookstore
 * @subpackage  Views
 */
class BookstoreViewCountries extends StoreViewLegacyPlular
{
}
?>