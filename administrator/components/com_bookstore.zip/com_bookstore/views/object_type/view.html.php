<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Object type item view class.
 *
 * @package     Bookstore
 * @subpackage  Views
 */
class BookstoreViewObject_type extends StoreViewLegacySingular
{
}
?>