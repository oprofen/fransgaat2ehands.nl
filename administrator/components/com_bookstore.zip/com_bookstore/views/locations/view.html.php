<?php
/**
 * @author
 * @copyright
 * @license
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Locations list view class.
 *
 * @package     Bookstore
 * @subpackage  Views
 */
class BookstoreViewLocations extends StoreViewLegacyPlular
{
}
?>