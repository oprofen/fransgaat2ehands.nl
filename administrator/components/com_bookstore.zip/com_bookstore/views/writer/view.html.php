<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Writer item view class.
 *
 * @package     Bookstore
 * @subpackage  Views
 */
class BookstoreViewWriter extends StoreViewLegacySingular
{
}
?>