<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Illistrator item view class.
 *
 * @package     Bookstore
 * @subpackage  Views
 */
class BookstoreViewIllistrator extends StoreViewLegacySingular
{
}
?>