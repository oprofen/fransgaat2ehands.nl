<?php
/**
 * @author
 * @copyright
 * @license
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Illistrators list view class.
 *
 * @package     Bookstore
 * @subpackage  Views
 */
class BookstoreViewIllistrators extends StoreViewLegacyPlular
{
}
?>