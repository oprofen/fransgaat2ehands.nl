<?php
/**
 * @author
 * @copyright
 * @license
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Assessments list view class.
 *
 * @package     Bookstore
 * @subpackage  Views
 */
class BookstoreViewLanguages extends StoreViewLegacyPlular
{
}
?>