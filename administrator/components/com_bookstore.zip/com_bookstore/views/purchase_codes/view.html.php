<?php
/**
 * @author
 * @copyright
 * @license
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Purchase codes list view class.
 *
 * @package     Bookstore
 * @subpackage  Views
 */
class BookstoreViewPurchase_codes extends StoreViewLegacyPlular
{
}
?>