<?php
/**
 * @author
 * @copyright
 * @license
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Translators list view class.
 *
 * @package     Bookstore
 * @subpackage  Views
 */
class BookstoreViewTranslators extends StoreViewLegacyPlular
{
}
?>