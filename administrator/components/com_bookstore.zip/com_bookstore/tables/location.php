<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Location table class.
 *
 * @package     Bookstore
 * @subpackage  Tables
 */
class BookstoreTableLocation extends StoreMultilangTable
{
}
?>