<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Illistrator table class.
 *
 * @package     Bookstore
 * @subpackage  Tables
 */
class BookstoreTableIllistrator extends StoreTable
{
}
?>