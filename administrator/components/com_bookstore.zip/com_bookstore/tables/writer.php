<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Author table class.
 *
 * @package     Bookstore
 * @subpackage  Tables
 */
class BookstoreTableWriter extends StoreTable
{
}
?>