<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Assessment table class.
 *
 * @package     Bookstore
 * @subpackage  Tables
 */
class BookstoreTableAssessment extends StoreMultilangTable
{
}
?>