<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Author table class.
 *
 * @package     Bookstore
 * @subpackage  Tables
 */
class BookstoreTablePurchase_code extends StoreTable
{
}
?>