<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Object_type table class.
 *
 * @package     Bookstore
 * @subpackage  Tables
 */
class BookstoreTableObject_type extends StoreMultilangTable
{
}
?>