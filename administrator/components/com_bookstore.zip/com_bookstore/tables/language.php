<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Language table class.
 *
 * @package     Bookstore
 * @subpackage  Tables
 */
class BookstoreTableLanguage extends StoreMultilangTable
{
}
?>