<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Translator table class.
 *
 * @package     Bookstore
 * @subpackage  Tables
 */
class BookstoreTableTranslator extends StoreTable
{
}
?>