<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Subcategory table class.
 *
 * @package     Bookstore
 * @subpackage  Tables
 */
class BookstoreTableSubcategory extends StoreMultilangTable
{
}
?>