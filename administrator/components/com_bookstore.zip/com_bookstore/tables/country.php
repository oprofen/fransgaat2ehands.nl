<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Country table class.
 *
 * @package     Bookstore
 * @subpackage  Tables
 */
class BookstoreTableCountry extends StoreMultilangTable
{
}
?>