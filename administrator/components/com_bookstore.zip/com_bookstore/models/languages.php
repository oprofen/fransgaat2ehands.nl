<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");



/**
 * List Model for languages.
 *
 * @package     Bookstore
 * @subpackage  Models
 */
class BookstoreModelLanguages extends StoreModelListMultiLang
{
}
?>