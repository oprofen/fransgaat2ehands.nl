<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");



/**
 * List Model for writers.
 *
 * @package     Bookstore
 * @subpackage  Models
 */
class BookstoreModelWriters extends StoreModelList
{
}
?>