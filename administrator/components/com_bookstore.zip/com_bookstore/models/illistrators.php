<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");



/**
 * List Model for illistrators.
 *
 * @package     Bookstore
 * @subpackage  Models
 */
class BookstoreModelIllistrators extends StoreModelList
{
}
?>