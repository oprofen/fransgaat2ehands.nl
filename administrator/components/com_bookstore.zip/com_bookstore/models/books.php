<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * List Model for books.
 *
 * @package     Bookstore
 * @subpackage  Models
 */
class BookstoreModelBooks extends StoreModelProductList
{
}
?>