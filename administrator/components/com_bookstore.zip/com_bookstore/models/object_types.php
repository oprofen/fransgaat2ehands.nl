<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");



/**
 * List Model for object types.
 *
 * @package     Bookstore
 * @subpackage  Models
 */
class BookstoreModelObject_types extends StoreModelListMultiLang
{
}
?>