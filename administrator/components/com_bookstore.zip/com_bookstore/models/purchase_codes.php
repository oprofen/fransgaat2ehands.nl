<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");



/**
 * List Model for purchase codes.
 *
 * @package     Bookstore
 * @subpackage  Models
 */
class BookstoreModelPurchase_codes extends StoreModelList
{
}
?>