<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");



/**
 * List Model for publishers.
 *
 * @package     Bookstore
 * @subpackage  Models
 */
class BookstoreModelPublishers extends StoreModelList
{
}
?>