<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");



/**
 * List Model for assessments.
 *
 * @package     Bookstore
 * @subpackage  Models
 */
class BookstoreModelAssessments extends StoreModelListMultiLang
{
}
?>