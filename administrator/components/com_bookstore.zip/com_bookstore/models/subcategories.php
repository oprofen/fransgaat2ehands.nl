<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");



/**
 * List Model for subcategories.
 *
 * @package     Bookstore
 * @subpackage  Models
 */
class BookstoreModelSubcategories extends StoreModelListMultiLang
{

	public $nameItem = 'subcategory';
}
?>