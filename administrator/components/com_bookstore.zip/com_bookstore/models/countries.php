<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");



/**
 * List Model for countries.
 *
 * @package     Bookstore
 * @subpackage  Models
 */
class BookstoreModelCountries extends StoreModelListMultiLang
{

	public $nameItem = 'country';
}
?>