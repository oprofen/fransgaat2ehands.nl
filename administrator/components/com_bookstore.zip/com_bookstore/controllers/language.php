<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Language item controller class.
 *
 * @package     Bookstore
 * @subpackage  Controllers
 */
class BookstoreControllerLanguage extends StoreControllerForm
{
}
?>