<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Publisher item controller class.
 *
 * @package     Bookstore
 * @subpackage  Controllers
 */
class BookstoreControllerPublisher extends StoreControllerForm
{
}
?>