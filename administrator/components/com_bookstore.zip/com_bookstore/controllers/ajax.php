<?php
/**
 * Created by PhpStorm.
 * User: Alexander
 * Date: 12.04.2016
 * Time: 14:48
 */

class BookstoreControllerAjax extends StoreControllerAjax
{
}