<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Author item controller class.
 *
 * @package     Bookstore
 * @subpackage  Controllers
 */
class BookstoreControllerWriter extends StoreControllerForm
{
}
?>