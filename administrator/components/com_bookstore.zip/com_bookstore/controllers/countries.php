<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Countries list controller class.
 *
 * @package     Bookstore
 * @subpackage  Controllers
 */
class BookstoreControllerCountries extends StoreControllerAdmin
{
	protected $nameItem = 'country';
}
?>