<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Purchase code item controller class.
 *
 * @package     Bookstore
 * @subpackage  Controllers
 */
class BookstoreControllerPurchase_code extends StoreControllerForm
{
}
?>