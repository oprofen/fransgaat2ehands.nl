<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Publishers list controller class.
 *
 * @package     Bookstore
 * @subpackage  Controllers
 */
class BookstoreControllerPublishers extends StoreControllerAdmin
{
}
?>