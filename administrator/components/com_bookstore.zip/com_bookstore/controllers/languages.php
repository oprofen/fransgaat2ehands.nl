<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Languages list controller class.
 *
 * @package     Bookstore
 * @subpackage  Controllers
 */
class BookstoreControllerLanguages extends StoreControllerAdmin
{
}
?>