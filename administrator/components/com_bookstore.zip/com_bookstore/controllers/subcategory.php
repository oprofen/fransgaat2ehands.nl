<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Subcategory item controller class.
 *
 * @package     Bookstore
 * @subpackage  Controllers
 */
class BookstoreControllerSubcategory extends StoreControllerForm
{
}
?>