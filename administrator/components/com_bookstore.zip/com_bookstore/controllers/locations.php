<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Locations list controller class.
 *
 * @package     Bookstore
 * @subpackage  Controllers
 */
class BookstoreControllerLocations extends StoreControllerAdmin
{
}
?>