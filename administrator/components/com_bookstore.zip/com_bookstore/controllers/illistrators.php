<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Illistrators list controller class.
 *
 * @package     Bookstore
 * @subpackage  Controllers
 */
class BookstoreControllerIllistrators extends StoreControllerAdmin
{
}
?>