<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Subcategory table class.
 *
 * @package     Dvdstore
 * @subpackage  Tables
 */
class DvdstoreTableFilm_production extends StoreMultilangTable
{
}
?>