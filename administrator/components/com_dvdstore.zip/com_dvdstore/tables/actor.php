<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Translator table class.
 *
 * @package     Dvdstore
 * @subpackage  Tables
 */
class DvdstoreTableActor extends StoreTable
{
}
?>