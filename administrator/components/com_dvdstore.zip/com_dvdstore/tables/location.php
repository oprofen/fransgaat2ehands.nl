<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Location table class.
 *
 * @package     Dvdstore
 * @subpackage  Tables
 */
class DvdstoreTableLocation extends StoreMultilangTable
{
    protected $dbName = 'bookstore_location';
    protected $assetNamePrefix = 'bookstore.location';
    protected $parentAssetNamePrefix = 'bookstore';
}
?>