<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Book table class.
 *
 * @package     Dvdstore
 * @subpackage  Tables
 */
class DvdstoreTableDvd extends StoreTableProduct
{
}
?>