<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Assessment table class.
 *
 * @package     Dvdstore
 * @subpackage  Tables
 */
class DvdstoreTableAssessment extends StoreMultilangTable
{
}
?>