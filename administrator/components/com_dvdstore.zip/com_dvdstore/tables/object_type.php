<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Object_type table class.
 *
 * @package     Dvdstore
 * @subpackage  Tables
 */
class DvdstoreTableObject_type extends StoreMultilangTable
{
}
?>