<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Author table class.
 *
 * @package     Dvdstore
 * @subpackage  Tables
 */
class DvdstoreTablePurchase_code extends StoreTable
{
    protected $dbName = 'bookstore_purchase_code';
    protected $assetNamePrefix = 'bookstore.purchase_code';
    protected $parentAssetNamePrefix = 'bookstore';
}
?>