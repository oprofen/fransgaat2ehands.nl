<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Country table class.
 *
 * @package     Dvdstore
 * @subpackage  Tables
 */
class DvdstoreTableCountry extends StoreMultilangTable
{
    protected $dbName = 'bookstore_country';
    protected $assetNamePrefix = 'bookstore.country';
    protected $parentAssetNamePrefix = 'bookstore';
}
?>