<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Publisher table class.
 *
 * @package     Dvdstore
 * @subpackage  Tables
 */
class DvdstoreTablePublisher extends StoreTable
{
}
?>