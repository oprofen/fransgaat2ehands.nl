<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Director table class.
 *
 * @package     Dvdstore
 * @subpackage  Tables
 */
class DvdstoreTableDirector extends StoreTable
{
}
?>