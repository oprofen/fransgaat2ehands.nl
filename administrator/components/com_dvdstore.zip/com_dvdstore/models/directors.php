<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");



/**
 * List Model for directors.
 *
 * @package     Bookstore
 * @subpackage  Models
 */
class DvdstoreModelDirectors extends StoreModelList
{
}
?>