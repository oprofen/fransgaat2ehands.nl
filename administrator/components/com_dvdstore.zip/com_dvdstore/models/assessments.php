<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");



/**
 * List Model for assessments.
 *
 * @package     Dvdstore
 * @subpackage  Models
 */
class DvdstoreModelAssessments extends StoreModelListMultiLang
{
}
?>