<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");



/**
 * List Model for locations.
 *
 * @package     Dvdstore
 * @subpackage  Models
 */
class DvdstoreModelLocations extends StoreModelListMultiLang
{
    public $dbName = 'bookstore_location';
}
?>