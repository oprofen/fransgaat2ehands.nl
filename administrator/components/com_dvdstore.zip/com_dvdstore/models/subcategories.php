<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");



/**
 * List Model for subcategories.
 *
 * @package     Dvdstore
 * @subpackage  Models
 */
class DvdstoreModelSubcategories extends StoreModelListMultiLang
{

	public $nameItem = 'subcategory';
}
?>