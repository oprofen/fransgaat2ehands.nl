<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");



/**
 * List Model for object types.
 *
 * @package     Dvdstore
 * @subpackage  Models
 */
class DvdstoreModelObject_types extends StoreModelListMultiLang
{
}
?>