<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");



/**
 * List Model for writers.
 *
 * @package     Dvdstore
 * @subpackage  Models
 */
class DvdstoreModelFilm_productions extends StoreModelList
{
}
?>