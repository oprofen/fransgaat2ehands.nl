<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");



/**
 * List Model for languages.
 *
 * @package     Dvdstore
 * @subpackage  Models
 */
class DvdstoreModelLanguages extends StoreModelListMultiLang
{
    public $dbName = 'bookstore_language';
}
?>