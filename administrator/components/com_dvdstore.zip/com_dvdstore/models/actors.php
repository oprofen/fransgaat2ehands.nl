<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");



/**
 * List Model for actors.
 *
 * @package     Bookstore
 * @subpackage  Models
 */
class DvdstoreModelActors extends StoreModelList
{
}
?>