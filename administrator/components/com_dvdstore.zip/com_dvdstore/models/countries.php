<?php
/**
 * @author
 * @copyright
 * @license
 */

defined("_JEXEC") or die("Restricted access");


/**
 * List Model for countries.
 *
 * @package     Dvdstore
 * @subpackage  Models
 */
class DvdstoreModelCountries extends StoreModelListMultiLang
{

    public $nameItem = 'country';
    public $dbName = 'bookstore_country';
}

?>