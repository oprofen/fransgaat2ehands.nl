<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");



/**
 * List Model for publishers.
 *
 * @package     Dvdstore
 * @subpackage  Models
 */
class DvdstoreModelPublishers extends StoreModelList
{
}
?>