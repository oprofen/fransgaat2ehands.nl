<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * List Model for dvds.
 *
 * @package     Dvdstore
 * @subpackage  Models
 */
class DvdstoreModelDvds extends StoreModelProductList
{
}
?>