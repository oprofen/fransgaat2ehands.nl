<?php
/**
 * @author
 * @copyright
 * @license
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Object types list view class.
 *
 * @package     Dvdstore
 * @subpackage  Views
 */
class DvdstoreViewObject_types extends StoreViewLegacyPlular
{
}
?>