<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Dvd item view class.
 *
 * @package     Dvdstore
 * @subpackage  Views
 */
class DvdstoreViewDvd extends StoreViewLegacySingular
{
}
?>