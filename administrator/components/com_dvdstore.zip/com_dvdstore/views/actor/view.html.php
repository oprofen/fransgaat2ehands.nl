<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Actor item view class.
 *
 * @package     Dvdstore
 * @subpackage  Views
 */
class DvdstoreViewActor extends StoreViewLegacySingular
{
}
?>