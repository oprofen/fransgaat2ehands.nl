<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Language item view class.
 *
 * @package     Bookstore
 * @subpackage  Views
 */
class DvdstoreViewLanguage extends StoreViewLegacySingular
{
}
?>