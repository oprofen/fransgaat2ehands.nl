<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");
require_once (JPATH_ADMINISTRATOR . '/components/com_bookstore/library/layout/editmultilang.php');
?>