<?php
/**
 * @author
 * @copyright
 * @license
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Actors list view class.
 *
 * @package     Dvdstore
 * @subpackage  Views
 */
class DvdstoreViewActors extends StoreViewLegacyPlular
{
}
?>