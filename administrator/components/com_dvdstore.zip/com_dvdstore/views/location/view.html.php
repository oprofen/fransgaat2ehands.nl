<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Location item view class.
 *
 * @package     Dvdstore
 * @subpackage  Views
 */
class DvdstoreViewLocation extends StoreViewLegacySingular
{
}
?>