<?php
/**
 * @author
 * @copyright
 * @license
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Languages list view class.
 *
 * @package     Bookstore
 * @subpackage  Views
 */
class DvdstoreViewLanguages extends StoreViewLegacyPlular
{
}
?>