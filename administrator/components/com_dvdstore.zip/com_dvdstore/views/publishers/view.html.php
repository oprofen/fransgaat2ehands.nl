<?php
/**
 * @author
 * @copyright
 * @license
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Publishers list view class.
 *
 * @package     Dvdstore
 * @subpackage  Views
 */
class DvdstoreViewPublishers extends StoreViewLegacyPlular
{
}
?>