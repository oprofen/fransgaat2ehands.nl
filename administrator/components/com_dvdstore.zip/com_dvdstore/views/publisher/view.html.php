<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Publisher item view class.
 *
 * @package     Dvdstore
 * @subpackage  Views
 */
class DvdstoreViewPublisher extends StoreViewLegacySingular
{
}
?>