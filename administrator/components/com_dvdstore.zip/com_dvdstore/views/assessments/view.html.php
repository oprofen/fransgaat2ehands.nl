<?php
/**
 * @author
 * @copyright
 * @license
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Assessments list view class.
 *
 * @package     Dvdstore
 * @subpackage  Views
 */
class DvdstoreViewAssessments extends StoreViewLegacyPlular
{
}
?>