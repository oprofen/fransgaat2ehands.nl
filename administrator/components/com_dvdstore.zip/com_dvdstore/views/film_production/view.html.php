<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Film production item view class.
 *
 * @package     Dvdstore
 * @subpackage  Views
 */
class DvdstoreViewFilm_production extends StoreViewLegacySingular
{
}
?>