<?php
/**
 * @author
 * @copyright
 * @license
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Locations list view class.
 *
 * @package     Dvdstore
 * @subpackage  Views
 */
class DvdstoreViewLocations extends StoreViewLegacyPlular
{
}
?>