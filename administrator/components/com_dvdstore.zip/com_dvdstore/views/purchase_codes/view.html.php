<?php
/**
 * @author
 * @copyright
 * @license
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Purchase codes list view class.
 *
 * @package     Dvdstore
 * @subpackage  Views
 */
class DvdstoreViewPurchase_codes extends StoreViewLegacyPlular
{
}
?>