<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Purchase code item view class.
 *
 * @package     Dvdstore
 * @subpackage  Views
 */
class DvdstoreViewPurchase_code extends StoreViewLegacySingular
{
}
?>