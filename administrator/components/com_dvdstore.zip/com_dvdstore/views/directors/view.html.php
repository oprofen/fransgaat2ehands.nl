<?php
/**
 * @author
 * @copyright
 * @license
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Directors list view class.
 *
 * @package     Dvdstore
 * @subpackage  Views
 */
class DvdstoreViewDirectors extends StoreViewLegacyPlular
{
}
?>