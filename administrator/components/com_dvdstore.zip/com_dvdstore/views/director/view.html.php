<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Director item view class.
 *
 * @package     Dvdstore
 * @subpackage  Views
 */
class DvdstoreViewDirector extends StoreViewLegacySingular
{
}
?>