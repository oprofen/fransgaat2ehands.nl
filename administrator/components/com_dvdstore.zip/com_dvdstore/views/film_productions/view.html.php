<?php
/**
 * @author
 * @copyright
 * @license
 */

defined("_JEXEC") or die("Restricted access");


/**
 * Film productions list view class.
 *
 * @package     Dvdstore
 * @subpackage  Views
 */
class DvdstoreViewFilm_productions extends StoreViewLegacyPlular
{
}
?>