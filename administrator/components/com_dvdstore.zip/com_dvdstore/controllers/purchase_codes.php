<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Purchase codes list controller class.
 *
 * @package     Dvdstore
 * @subpackage  Controllers
 */
class DvdstoreControllerPurchase_codes extends StoreControllerAdmin
{
}
?>