<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Translators list controller class.
 *
 * @package     Dvdstore
 * @subpackage  Controllers
 */
class DvdstoreControllerTranslators extends StoreControllerAdmin
{
}
?>