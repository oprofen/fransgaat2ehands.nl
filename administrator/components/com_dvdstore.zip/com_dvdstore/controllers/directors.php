<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Directors list controller class.
 *
 * @package     Dvdstore
 * @subpackage  Controllers
 */
class DvdstoreControllerDirectors extends StoreControllerAdmin
{
}
?>