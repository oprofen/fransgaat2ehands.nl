<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Object_type item controller class.
 *
 * @package     Dvdstore
 * @subpackage  Controllers
 */
class DvdstoreControllerObject_type extends StoreControllerForm
{
}
?>