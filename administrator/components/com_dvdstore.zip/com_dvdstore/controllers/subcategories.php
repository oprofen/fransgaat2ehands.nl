<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Subcategories list controller class.
 *
 * @package     Dvdstore
 * @subpackage  Controllers
 */
class DvdstoreControllerSubcategories extends StoreControllerAdmin
{
	protected $nameItem = 'subcategory';
}
?>