<?php
/**
 * @author		
 * @copyright	
 * @license		
 */

defined("_JEXEC") or die("Restricted access");

/**
 * Book item controller class.
 *
 * @package     Dvdstore
 * @subpackage  Controllers
 */
class DvdstoreControllerDvd extends StoreControllerProductForm
{
}
?>